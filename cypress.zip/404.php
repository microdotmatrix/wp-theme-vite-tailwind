<?php get_header() ?>

    <div class="grid place-content-center h-full text-center">

        <h1 class="text-5xl font-semibold">404</h1>
        <div class="mt-4">
            <h2>Not found</h2>
        </div>

    </div>

<?php get_footer() ?>