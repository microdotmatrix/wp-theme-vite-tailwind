<?php get_header() ?>

<main class="flex-grow px-4 py-4">
  <div class="place-content-center flex items-center h-full w-full container mx-auto">
    <?php the_content() ?>
  </div>
</main>

<div class="w-full h-full">

</div>

<?php get_footer() ?>